<hr>

<footer>
  <div class="text-muted pull-right">
      **2020** Bookart. Hosted on AWS by <a href="https://www.linkedin.com/in/saurabhpundir00">Saurabh Pundir </a>,<a href="http://www.linkedin.com/in/abhishek-kumar-84ba41193"> Abhishek Kumar </a>, <a href="https://www.linkedin.com/in/sparsh-agrawal-ba7266171"> Sparsh Agrawal. </a>
  </div>
</footer>
</div> 


<script type="text/javascript" src="./bootstrap/js/jquery-2.1.4.min.js"></script>
<script type="text/javascript" src="./bootstrap/js/bootstrap.min.js"></script>
</body>
</html>